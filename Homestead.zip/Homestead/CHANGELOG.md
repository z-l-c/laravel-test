# Release Notes

Please visit https://github.com/laravel/homestead/releases for details about each release.

Official documentation [is located here](http://laravel.com/docs/homestead).
